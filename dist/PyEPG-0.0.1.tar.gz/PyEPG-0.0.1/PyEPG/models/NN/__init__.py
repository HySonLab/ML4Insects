from .CNN1D import CNN1D
from .CNN2D import CNN2D  
from .ResNet import ResNet  
from .MLP import MLP
